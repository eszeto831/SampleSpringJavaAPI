package com.seatoadgames.SampleSpringJavaAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleSpringJavaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleSpringJavaApiApplication.class, args);
	}

}
